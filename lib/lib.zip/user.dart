class User {

  final String userName;

  User(this.userName);
}